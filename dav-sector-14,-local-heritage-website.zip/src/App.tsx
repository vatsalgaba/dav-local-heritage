/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Home } from './pages/Home';
import { RegionDetail } from './pages/RegionDetail';
import { History } from './pages/History';
import { Culture } from './pages/Culture';
import { AudioPlayer } from './components/AudioPlayer';
import { AnimatePresence } from 'motion/react';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-[#050505] text-[#f5f5ed] font-sans selection:bg-[#c5a059] selection:text-black">
        <AudioPlayer />
        <AnimatePresence mode="wait">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/region/:id" element={<RegionDetail />} />
            <Route path="/history" element={<History />} />
            <Route path="/culture" element={<Culture />} />
          </Routes>
        </AnimatePresence>
      </div>
    </Router>
  );
}

