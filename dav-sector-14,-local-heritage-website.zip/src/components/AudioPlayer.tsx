import { useState, useRef, useEffect } from 'react';
import { Music, Music2 } from 'lucide-react';
import { motion } from 'motion/react';

export function AudioPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Note: Browsers block auto-play without user interaction.
  // We will start it once the user clicks anywhere or interacts with the site.
  
  const togglePlay = () => {
    if (audioRef.current) {
      setIsPlaying(prev => {
        const nextState = !prev;
        if (nextState) {
          audioRef.current?.play().catch(e => console.error("Play error:", e));
        } else {
          audioRef.current?.pause();
        }
        window.dispatchEvent(new CustomEvent('music-status', { detail: { isPlaying: nextState } }));
        return nextState;
      });
    }
  };

  useEffect(() => {
    const handleToggleEvent = () => togglePlay();
    window.addEventListener('toggle-audio', handleToggleEvent);
    return () => window.removeEventListener('toggle-audio', handleToggleEvent);
  }, []); 

  useEffect(() => {
    const handleFirstInteraction = () => {
      if (audioRef.current && !isPlaying) {
        audioRef.current.play().then(() => {
          setIsPlaying(true);
          window.dispatchEvent(new CustomEvent('music-status', { detail: { isPlaying: true } }));
        }).catch(err => console.log("Audio play blocked", err));
      }
      window.removeEventListener('click', handleFirstInteraction);
    };

    window.addEventListener('click', handleFirstInteraction);
    return () => window.removeEventListener('click', handleFirstInteraction);
  }, [isPlaying]);

  return (
    <div className="fixed bottom-6 right-6 z-50 pointer-events-none">
      <audio
        ref={audioRef}
        loop
        src="https://mp3tourl.com/audio/1778778606062-7553b4b0-df28-446a-9de3-f1905cbaa607.mp3" 
      />
    </div>
  );
}
