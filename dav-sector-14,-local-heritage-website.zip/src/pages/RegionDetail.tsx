import { useParams, Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { regions } from '../data/regions';
import { ArrowLeft, History, MapPin, Palette } from 'lucide-react';
import { useEffect } from 'react';

export function RegionDetail() {
  const { id } = useParams();
  const region = regions.find(r => r.id === id);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  if (!region) return <div className="h-screen flex items-center justify-center">Region not found</div>;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen relative"
      style={{ backgroundColor: region.theme.background, color: region.theme.contrast }}
    >
      {/* Texture Layer */}
      <div 
        className={`absolute inset-0 opacity-[0.05] pointer-events-none mix-blend-multiply ${region.patternClass || ''}`} 
      />

      {/* Hero Section */}
      <div className="h-[70vh] relative overflow-hidden">
        <motion.img 
          initial={{ scale: 1.2 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1.5 }}
          src={region.image} 
          alt={region.name} 
          className="w-full h-full object-cover brightness-90"
          referrerPolicy="no-referrer"
        />
        <div 
          className="absolute inset-0" 
          style={{ background: `linear-gradient(to bottom, transparent, ${region.theme.background})` }}
        />
        
        <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <Link 
              to="/" 
              className="inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] mb-8 hover:tracking-[0.4em] transition-all"
              style={{ color: region.theme.primary }}
            >
              <ArrowLeft className="w-3 h-3" /> Back to Museum
            </Link>
            <div className="flex items-center justify-center gap-6 mb-4">
              <h1 className={`${region.theme.headingFont} text-6xl md:text-8xl`} style={{ color: region.theme.contrast }}>{region.name}</h1>
            </div>
            <p className={`${region.theme.bodyFont} italic text-xl md:text-2xl`} style={{ color: region.theme.primary }}>{region.title}</p>
          </motion.div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-6 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 mb-24">
          <motion.div
            initial={{ x: -20, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
          >
            <h2 className={`${region.theme.headingFont} text-3xl mb-6`} style={{ color: region.theme.secondary }}>The Essence</h2>
            <p className={`${region.theme.bodyFont} text-lg leading-relaxed opacity-80`} style={{ color: region.theme.contrast }}>
              {region.description}
            </p>
            {id === 'chittorgarh' && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="mt-8 rounded-2xl overflow-hidden shadow-xl"
              >
                <img 
                  src="https://lh3.googleusercontent.com/d/1QVeqfVFW6DXhX7e_0oSv33EkTOp9sSrK" 
                  alt="Chittorgarh Essence" 
                  className="w-full h-auto object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            )}
            {id === 'jodhpur' && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="mt-8 rounded-2xl overflow-hidden shadow-xl"
              >
                <img 
                  src="https://lh3.googleusercontent.com/d/1y7c3LK6xOLmpN5CEEsBRB4YxOcfhcytI" 
                  alt="Jodhpur Essence" 
                  className="w-full h-auto object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            )}
            {id === 'jaipur' && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="mt-8 rounded-2xl overflow-hidden shadow-xl"
              >
                <img 
                  src="https://lh3.googleusercontent.com/d/1-lkRZjGO-5AHTBMRcSVxe6zsntHY38ID" 
                  alt="Jaipur Essence" 
                  className="w-full h-auto object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            )}
            {id === 'bikaner' && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="mt-8 rounded-2xl overflow-hidden shadow-xl"
              >
                <img 
                  src="https://lh3.googleusercontent.com/d/1vVLuLvEhoWG4dEv_zIPdgE_5FmfZORHl" 
                  alt="Bikaner Essence" 
                  className="w-full h-auto object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            )}
            {id === 'pushkar' && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
                className="mt-8 rounded-2xl overflow-hidden shadow-xl"
              >
                <img 
                  src="https://lh3.googleusercontent.com/d/1PPoQHiAOex6PU46Hin6jaBYlGqTtpoBY" 
                  alt="Pushkar Essence" 
                  className="w-full h-auto object-cover"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            )}
          </motion.div>
          <motion.div
            initial={{ x: 20, opacity: 0 }}
            whileInView={{ x: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="flex flex-col gap-6"
          >
            {id === 'chittorgarh' ? (
              <div className="flex flex-row items-center gap-4 md:gap-8 mb-8">
                {/* Rani Padmini */}
                <div className="relative group">
                  <motion.img 
                    whileHover={{ scale: 1.05, rotate: 2 }}
                    src="https://lh3.googleusercontent.com/d/1xa2Ss2xLmthKMnq2fXvMn23dRS5EMm79" 
                    alt="Rani Padmini Icon" 
                    className="w-24 h-24 md:w-36 md:h-36 object-contain cursor-help pointer-events-auto filter drop-shadow-[0_0_30px_rgba(196,154,68,0.6)]"
                    referrerPolicy="no-referrer"
                  />
                  {/* Tooltip / Legend Popup */}
                  <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-8 w-64 md:w-[400px] p-6 bg-[#0a0a0a]/98 backdrop-blur-3xl rounded-[2rem] opacity-0 scale-95 group-hover:opacity-100 group-hover:scale-100 transition-all duration-700 pointer-events-none z-50 text-left border border-[#C49A44]/40 shadow-[0_40px_100px_rgba(0,0,0,1)]">
                    <h3 className="font-medieval text-[#C49A44] mb-4 italic text-lg md:text-xl leading-snug tracking-wide">
                      "Darr naam ka gehna Padmavati ne kabhi pehna hi nahi"
                    </h3>
                    <p className="font-serif text-[10px] md:text-xs leading-relaxed text-[#F3E9D2] opacity-95">
                      -I am Rani Padmini of Chittorgarh — fearless, proud, and unyielding. I stood by my king, Rawal Ratan Singh, as our fort faced Alauddin Khilji’s relentless siege. When capture threatened us, I chose fire over surrender, leading the legendary jauhar to protect our honor. My courage turned despair into legend, my sacrifice immortal, and my spirit a beacon for all who value honor, dignity, and fearless defiance.
                    </p>
                    {/* Decorative Pointer */}
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-[#0a0a0a] rotate-45 border-b border-r border-[#C49A44]/40" />
                  </div>
                </div>

                {/* Maharana Kumbha */}
                <div className="relative group">
                  <motion.img 
                    whileHover={{ scale: 1.05, rotate: -2 }}
                    src="https://lh3.googleusercontent.com/d/1npLg0PNj2iWNQ6xuLMawHM2u-gEeVoBK" 
                    alt="Maharana Kumbha Icon" 
                    className="w-24 h-24 md:w-36 md:h-36 object-contain cursor-help pointer-events-auto filter drop-shadow-[0_0_30px_rgba(196,154,68,0.6)]"
                    referrerPolicy="no-referrer"
                  />
                  {/* Tooltip / Legend Popup */}
                  <div className="absolute left-1/2 -translate-x-1/2 bottom-full mb-8 w-64 md:w-[400px] p-6 bg-[#0a0a0a]/98 backdrop-blur-3xl rounded-[2rem] opacity-0 scale-95 group-hover:opacity-100 group-hover:scale-100 transition-all duration-700 pointer-events-none z-50 text-left border border-[#C49A44]/40 shadow-[0_40px_100px_rgba(0,0,0,1)]">
                    <h3 className="font-hindi text-[#C49A44] mb-4 text-base md:text-lg leading-relaxed tracking-wide">
                      "जो राजा न्याय की उपेक्षा करता है, उसका राज्य शत्रु से पहले ही दुर्बल हो जाता है।"
                    </h3>
                    <p className="font-serif text-[10px] md:text-xs leading-relaxed text-[#F3E9D2] opacity-95">
                      Meet Maharana Kumbha, the undefeated Rajput Warrior who built the historical Kumbhalgarh Fort in the 15th Century. He transformed Mewar into a powerhouse and Chittorgarh fort into military strategic strong hold. He also built iconic 37-metre high Vijay Stambha to commemorate his triumph over Malwa.
                    </p>
                    {/* Decorative Pointer */}
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-[#0a0a0a] rotate-45 border-b border-r border-[#C49A44]/40" />
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-start gap-4">
                <div 
                  className="p-3 rounded-full"
                  style={{ backgroundColor: `${region.theme.primary}20`, color: region.theme.primary }}
                >
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h3 className={`${region.theme.bodyFont} font-semibold text-sm uppercase tracking-wider mb-1`} style={{ color: region.theme.contrast }}>Key Landmark</h3>
                  <p className={`${region.theme.bodyFont} opacity-70`} style={{ color: region.theme.contrast }}>{region.landmark}</p>
                </div>
              </div>
            )}
            <div className="flex items-start gap-4">
              <div 
                className="p-3 rounded-full"
                style={{ backgroundColor: `${region.theme.primary}20`, color: region.theme.primary }}
              >
                <History className="w-5 h-5" />
              </div>
              <div>
                <h3 className={`${region.theme.bodyFont} font-semibold text-sm uppercase tracking-wider mb-1`} style={{ color: region.theme.contrast }}>Heritage</h3>
                <p className={`${region.theme.bodyFont} opacity-70`} style={{ color: region.theme.contrast }}>{region.history}</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div 
                className="p-3 rounded-full"
                style={{ backgroundColor: `${region.theme.primary}20`, color: region.theme.primary }}
              >
                <Palette className="w-5 h-5" />
              </div>
              <div>
                <h3 className={`${region.theme.bodyFont} font-semibold text-sm uppercase tracking-wider mb-1`} style={{ color: region.theme.contrast }}>Culture</h3>
                <p className={`${region.theme.bodyFont} opacity-70`} style={{ color: region.theme.contrast }}>{region.culture}</p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Extended Information Sections - ADDED MORE INFO HERE */}
        <div className="space-y-32">
          <motion.section
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
          >
            <h2 className={`${region.theme.headingFont} text-4xl mb-8 border-b pb-4`} style={{ borderColor: `${region.theme.primary}40` }}>
              Grand Architecture
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <p className={`${region.theme.bodyFont} text-lg leading-relaxed opacity-80`}>
                  The architecture of {region.name} is a testament to the region's royal past. {region.architecture}
                </p>
                <p className={`${region.theme.bodyFont} text-lg leading-relaxed opacity-80 italic`}>
                  "In Rajasthan, buildings are not just structures; they are vessels for our history and our soul."
                </p>
              </div>
              {(region.landmarkImage || id === 'neemrana' || id === 'pushkar') && (
                <div className="relative rounded-2xl overflow-hidden shadow-2xl">
                  <img 
                    src={
                      id === 'jodhpur' ? "https://lh3.googleusercontent.com/d/1_PBKh6aX0uiEDwkD4lQ_uIsWAphH0Sja" : 
                      id === 'jaipur' ? "https://lh3.googleusercontent.com/d/1m5CpSLlh0qVnBj8_pxqsiUERQlV-0S_f" :
                      id === 'bikaner' ? "https://lh3.googleusercontent.com/d/1eq2oJPiBDPbtBcNkmtxQRhl4-zvrJx-a" :
                      id === 'neemrana' ? "https://lh3.googleusercontent.com/d/1-_2sr2JkalC0FzYRSsijMZcX4qpdlb8P" :
                      id === 'pushkar' ? "https://lh3.googleusercontent.com/d/1tPom_bvo8FynDQZOlXtF_kKw9p16ksSh" :
                      region.landmarkImage
                    } 
                    alt={region.landmark} 
                    className="w-full h-80 object-cover" 
                    referrerPolicy="no-referrer" 
                  />
                  <div className="absolute bottom-0 left-0 right-0 p-4 bg-black/60 backdrop-blur-sm text-white text-xs tracking-widest uppercase">
                    Visual Archive: {(id === 'jodhpur' || id === 'jaipur' || id === 'bikaner' || id === 'neemrana' || id === 'pushkar') ? 'Architecture Detail' : region.landmark}
                  </div>
                </div>
              )}
            </div>
          </motion.section>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-20">
            <motion.section
              initial={{ x: -20, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
            >
              <h2 className={`${region.theme.headingFont} text-3xl mb-6`} style={{ color: region.theme.secondary }}>Ancient Folklore</h2>
              <p className={`${region.theme.bodyFont} text-lg leading-relaxed opacity-80 mb-6 font-traditional`}>
                The whispers of the past are loud in {region.name}. {region.folklore}
              </p>
              <div className="p-8 border-l-4 rounded-r-xl bg-black/5" style={{ borderColor: region.theme.primary }}>
                <p className="text-sm opacity-60 italic">
                  Legend says that the winds of {region.name} still carry the echoes of the kings and queens who walked these grounds centuries ago.
                </p>
              </div>
            </motion.section>

            <motion.section
              initial={{ x: 20, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
            >
              <h2 className={`${region.theme.headingFont} text-3xl mb-6`} style={{ color: region.theme.secondary }}>The Royal Kitchen</h2>
              <p className={`${region.theme.bodyFont} text-lg leading-relaxed opacity-80 mb-8`}>
                Flavor is the heart of Rajputana hospitality. {region.cuisine}
              </p>
              {id === 'chittorgarh' && (
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    className="rounded-xl overflow-hidden shadow-lg aspect-square md:aspect-video"
                  >
                    <img 
                      src="https://lh3.googleusercontent.com/d/1cahXVOwYwSpf6eh3_-D41WEas1jnToLD" 
                      alt="Royal Kitchen 1" 
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.1 }}
                    className="rounded-xl overflow-hidden shadow-lg aspect-square md:aspect-video"
                  >
                    <img 
                      src="https://lh3.googleusercontent.com/d/1gOyPxGaeaRVmYhtgcLMPSrKEOSr-2ESu" 
                      alt="Royal Kitchen 2" 
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                </div>
              )}
              {id === 'jodhpur' && (
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    className="rounded-xl overflow-hidden shadow-lg aspect-square md:aspect-video"
                  >
                    <img 
                      src="https://lh3.googleusercontent.com/d/1eJzKtxPQQ0QFQ2M_zHRtBJcIHpYJoOBw" 
                      alt="Jodhpur Royal Kitchen 1" 
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.1 }}
                    className="rounded-xl overflow-hidden shadow-lg aspect-square md:aspect-video"
                  >
                    <img 
                      src="https://lh3.googleusercontent.com/d/16WlPEHEDg-oq-YKNg3Iyyhcf9oUWdKEj" 
                      alt="Jodhpur Royal Kitchen 2" 
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                </div>
              )}
              {id === 'jaipur' && (
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    className="rounded-xl overflow-hidden shadow-lg aspect-square md:aspect-video"
                  >
                    <img 
                      src="https://lh3.googleusercontent.com/d/1LiswwMPZMVOA78z554Z6CwshmzMqdQ2E" 
                      alt="Jaipur Royal Kitchen 1" 
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.1 }}
                    className="rounded-xl overflow-hidden shadow-lg aspect-square md:aspect-video"
                  >
                    <img 
                      src="https://lh3.googleusercontent.com/d/1oq3rzQS062kdgwB1jJ4_3Z1hcdhgsViC" 
                      alt="Jaipur Royal Kitchen 2" 
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                </div>
              )}
              {id === 'bikaner' && (
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    className="rounded-xl overflow-hidden shadow-lg aspect-square md:aspect-video"
                  >
                    <img 
                      src="https://lh3.googleusercontent.com/d/1Wsi-7LMvTjag5rNqih55EdADZFtwbM8D" 
                      alt="Bikaner Royal Kitchen 1" 
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.1 }}
                    className="rounded-xl overflow-hidden shadow-lg aspect-square md:aspect-video"
                  >
                    <img 
                      src="https://lh3.googleusercontent.com/d/1wucnlmc-qQySzAjYBzch9L8Zyg4wj8XT" 
                      alt="Bikaner Royal Kitchen 2" 
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                </div>
              )}
              {id === 'neemrana' && (
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    className="rounded-xl overflow-hidden shadow-lg aspect-square md:aspect-video"
                  >
                    <img 
                      src="https://lh3.googleusercontent.com/d/11MbgWp7kWFzEciuBmxya_8fJNV-HiTNl" 
                      alt="Neemrana Royal Kitchen 1" 
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.1 }}
                    className="rounded-xl overflow-hidden shadow-lg aspect-square md:aspect-video"
                  >
                    <img 
                      src="https://lh3.googleusercontent.com/d/1TGTNaHaO_y_Jy0wieaWH--aNixfdX606" 
                      alt="Neemrana Royal Kitchen 2" 
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                </div>
              )}
              {id === 'pushkar' && (
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    className="rounded-xl overflow-hidden shadow-lg aspect-square md:aspect-video"
                  >
                    <img 
                      src="https://lh3.googleusercontent.com/d/1K3tyPkSHnTDiFXoIDo3E3kYIeBBFFna0" 
                      alt="Pushkar Royal Kitchen 1" 
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 0.1 }}
                    className="rounded-xl overflow-hidden shadow-lg aspect-square md:aspect-video"
                  >
                    <img 
                      src="https://lh3.googleusercontent.com/d/1WU0Lw_Oqw_SfNGNOGzMUkuaaHAw7wP1X" 
                      alt="Pushkar Royal Kitchen 2" 
                      className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                  </motion.div>
                </div>
              )}
              <div className="flex flex-wrap gap-3">
                {['Spices', 'Traditional', 'Organic', 'Royal Recipes'].map(tag => (
                  <span key={tag} className="px-4 py-1 text-[10px] uppercase tracking-widest border rounded-full opacity-60" style={{ borderColor: region.theme.contrast }}>
                    {tag}
                  </span>
                ))}
              </div>
            </motion.section>
          </div>

          {/* Top Attractions Section */}
          <motion.section
            initial={{ y: 20, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
          >
            <h2 className={`${region.theme.headingFont} text-4xl md:text-5xl mb-16 text-center uppercase tracking-widest`} style={{ color: region.theme.secondary }}>
              Top Attractions
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              {region.attractions.map((attraction, idx) => (
                <motion.div 
                  key={idx}
                  whileHover={{ y: -8 }}
                  className="group"
                >
                  <div className="relative h-72 mb-8 overflow-hidden rounded-2xl border border-black/5 shadow-lg group-hover:shadow-2xl transition-all duration-500">
                    <img 
                      src={attraction.image} 
                      alt={attraction.name} 
                      className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110 grayscale-0"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-colors duration-500" />
                  </div>
                  <h3 className={`${region.theme.bodyFont} font-bold text-xl mb-3`} style={{ color: region.theme.contrast }}>{attraction.name}</h3>
                  <p className="text-sm opacity-60 leading-relaxed italic">{attraction.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.section>

          <motion.section
            initial={{ scale: 0.95, opacity: 0 }}
            whileInView={{ scale: 1, opacity: 1 }}
            viewport={{ once: true }}
            className="p-12 text-center rounded-3xl border-2 border-dashed"
            style={{ borderColor: `${region.theme.primary}20` }}
          >
            <h2 className={`${region.theme.headingFont} text-4xl mb-6`}>Traveler's Footnote</h2>
            <p className="max-w-2xl mx-auto opacity-70 leading-relaxed mb-8">
              When visiting {region.name}, look beyond the facade of the forts. Notice the way the light hits the sandstone at golden hour, the intricate patterns of the local textiles, and the warmth of the people who call this majestic territory home.
            </p>
            {region.coordinates && (
                <div className="text-[10px] uppercase tracking-[0.4em] opacity-40">
                  Coordinates: {region.coordinates.lat}° N, {region.coordinates.lng}° E
                </div>
              )}
            </motion.section>
          </div>

        {/* Action Call */}
        <div className="text-center pt-20 mt-32 border-t" style={{ borderColor: `${region.theme.contrast}10` }}>
          <Link 
            to="/" 
            className={`${region.theme.bodyFont} inline-block px-12 py-4 border italic text-xl transition-all duration-500 rounded-full`}
            style={{ 
              borderColor: region.theme.accent, 
              color: region.theme.accent,
              backgroundColor: 'transparent'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = region.theme.accent;
              e.currentTarget.style.color = region.theme.background;
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
              e.currentTarget.style.color = region.theme.accent;
            }}
          >
            Continue Journey
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
