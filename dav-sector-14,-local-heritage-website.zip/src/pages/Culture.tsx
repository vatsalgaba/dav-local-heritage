import { motion } from 'motion/react';
import { Music, Palette, Tent, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Culture() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="pt-20 pb-20 px-6 min-h-screen bg-[#050505]"
    >
      <div className="max-w-6xl mx-auto">
        <header className="text-center mb-24">
          <motion.span 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="text-[10px] uppercase tracking-[0.6em] text-[#c5a059] font-bold"
          >
            The Soul of the Desert
          </motion.span>
          <motion.h1 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="font-royal text-5xl md:text-7xl mt-6 mb-8 text-[#f5f5ed]"
          >
            Living Traditions
          </motion.h1>
          <div className="w-32 h-[1px] bg-[#c5a059]/40 mx-auto" />
        </header>

        <div className="space-y-40">
          {/* Folk Music & Dance */}
          <section className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div className="order-2 lg:order-1 space-y-8">
              <div className="flex items-center gap-4 text-[#c5a059]">
                <Music className="w-6 h-6" />
                <h2 className="font-royal text-3xl">Echoes of the Thar</h2>
              </div>
              <p className="font-traditional italic text-lg leading-relaxed text-white/70">
                The folk music of Rajasthan is as diverse as its landscape. From the nomadic Manganiyars who sing of ancient kings, to the Langas whose melodies are passed down as hereditary treasures.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="p-6 border border-white/5 rounded-xl bg-white/[0.02]">
                  <h3 className="font-royal text-[#c5a059] mb-2 uppercase text-sm tracking-widest">Kalbelia Dance</h3>
                  <p className="text-xs text-white/50 leading-relaxed italic">The serpent-charming dance recognized by UNESCO as intangible heritage.</p>
                </div>
                <div className="p-6 border border-white/5 rounded-xl bg-white/[0.02]">
                  <h3 className="font-royal text-[#c5a059] mb-2 uppercase text-sm tracking-widest">The Kamayacha</h3>
                  <p className="text-xs text-white/50 leading-relaxed italic">An ancient bowed instrument that resonates with the haunting spirit of desert winds.</p>
                </div>
              </div>
            </div>
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              viewport={{ once: true }}
              className="order-1 lg:order-2 rounded-2xl overflow-hidden aspect-video shadow-2xl relative group"
            >
              <img 
                src="https://images.unsplash.com/photo-1596422846543-75c6fc18a493?auto=format&fit=crop&q=80&w=1200" 
                alt="Folk Performers"
                className="w-full h-full object-cover grayscale transition-all duration-700 group-hover:grayscale-0"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            </motion.div>
          </section>

          {/* Master Crafts */}
          <section className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <motion.div 
              initial={{ x: -30, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              viewport={{ once: true }}
              className="rounded-2xl overflow-hidden aspect-video shadow-2xl relative group"
            >
              <img 
                src="https://images.unsplash.com/photo-1524230659192-358c71cc1703?auto=format&fit=crop&q=80&w=1200" 
                alt="Pottery Art"
                className="w-full h-full object-cover grayscale transition-all duration-700 group-hover:grayscale-0"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            </motion.div>
            <div className="space-y-8">
              <div className="flex items-center gap-4 text-[#c5a059]">
                <Palette className="w-6 h-6" />
                <h2 className="font-royal text-3xl">Woven Wonders</h2>
              </div>
              <p className="font-traditional italic text-lg leading-relaxed text-white/70">
                Crafting in Rajasthan is a ritual. Whether it's the blue pottery of Jaipur or the miniature paintings of Bikaner, every stroke carries a lineage of centuries.
              </p>
              <ul className="space-y-4">
                <li className="flex items-center gap-4 text-sm text-white/60">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#c5a059]" />
                  <span>Blue Pottery: Quartz-based ceramic without clay.</span>
                </li>
                <li className="flex items-center gap-4 text-sm text-white/60">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#c5a059]" />
                  <span>Bandhani: Mastery of tie-and-dye patterns.</span>
                </li>
                <li className="flex items-center gap-4 text-sm text-white/60">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#c5a059]" />
                  <span>Thewa: Intricate gold work on glass.</span>
                </li>
              </ul>
            </div>
          </section>

          {/* Festivals */}
          <section className="text-center space-y-16">
            <div className="space-y-4">
              <div className="flex justify-center text-[#c5a059] mb-4">
                <Sparkles className="w-8 h-8" />
              </div>
              <h2 className="font-royal text-4xl">Festivals of Color</h2>
              <p className="max-w-2xl mx-auto text-white/40 italic">Seasonal celebrations that transform the landscape into a kaleidoscope of joy.</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {['Pushkar Mela', 'Gangaur', 'Teej'].map((fest) => (
                <div key={fest} className="p-8 border border-[#c5a059]/10 rounded-2xl bg-white/[0.01] hover:border-[#c5a059]/30 transition-all">
                  <h3 className="font-royal text-[#c5a059] text-xl mb-4 tracking-widest">{fest}</h3>
                  <div className="h-[1px] w-12 bg-[#c5a059]/20 mx-auto mb-4" />
                  <p className="text-xs text-white/40 leading-relaxed font-traditional">
                    A grand spectacle where spirituality meets the vibrant commerce of life and cattle.
                  </p>
                </div>
              ))}
            </div>
          </section>
        </div>

        <div className="mt-40 text-center">
          <Link to="/" className="inline-block px-12 py-4 border border-[#c5a059] text-[10px] uppercase tracking-[0.4em] text-[#c5a059] hover:bg-[#c5a059] hover:text-black transition-all rounded-full font-bold">
            Return to Entrance
          </Link>
        </div>
      </div>
    </motion.div>
  );
}
