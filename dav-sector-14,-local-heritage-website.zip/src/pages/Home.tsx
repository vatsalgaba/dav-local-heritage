import { motion, useScroll, useTransform } from 'motion/react';
import { regions } from '../data/regions';
import { Link } from 'react-router-dom';
import { useRef, useState, useEffect } from 'react';
import { Music } from 'lucide-react';

export function Home() {
  const { scrollY } = useScroll();
  const [musicPlaying, setMusicPlaying] = useState(false);
  
  // Parallax and scroll effects
  const y1 = useTransform(scrollY, [0, 500], [0, 200]);
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);
  const heroScale = useTransform(scrollY, [0, 500], [1, 1.05]);

  useEffect(() => {
    const handleStatus = (e: any) => {
      setMusicPlaying(e.detail.isPlaying);
    };
    window.addEventListener('music-status', handleStatus);
    return () => window.removeEventListener('music-status', handleStatus);
  }, []);

  return (
    <motion.main 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1, filter: musicPlaying ? "brightness(1.05) contrast(1.02)" : "brightness(1) contrast(1)" }}
      exit={{ opacity: 0 }}
      className="relative transition-[filter] duration-1000"
    >
      {/* Hero Section - Global Museum Background Aesthetic */}
      <section className="relative h-screen flex flex-col items-center justify-center overflow-hidden">
        <motion.div 
          style={{ 
            opacity, 
            scale: heroScale
          }}
          className="absolute inset-0 z-0"
        >
          <img 
            src="https://lh3.googleusercontent.com/d/1dNBhKUe3RJxYZH-LQ31gw41LCNe0An6T" 
            alt="Rajasthan Heritage Architecture"
            className={`w-full h-full object-cover transition-all duration-1000 ${musicPlaying ? 'brightness-[0.85] contrast-[1.1]' : 'brightness-[0.7] contrast-[1.05]'}`}
            referrerPolicy="no-referrer"
          />
          <div className={`absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/80 transition-opacity duration-1000 ${musicPlaying ? 'opacity-60' : 'opacity-100'}`} />
        </motion.div>

        <motion.div 
          style={{ y: y1, opacity }}
          className="relative z-20 text-center flex flex-col items-center px-6"
        >
          {/* Main Heritage Greeting */}
          <div className="flex flex-col items-center">
            <div className="flex items-center gap-6 mb-4">
              <h2 className={`font-royal text-xl md:text-3xl light-royal-text tracking-[0.2em] uppercase font-bold museum-text-shadow leading-relaxed transition-all duration-1000 ${musicPlaying ? 'scale-105' : 'scale-100'}`}>
                गीत री धड़कण साथ • पधारो म्हारो राजस्थान
              </h2>
              <motion.div 
                whileHover={{ scale: 1.2, rotate: 10, filter: "brightness(1.5)" }}
                whileTap={{ scale: 0.9 }}
                className="cursor-pointer pointer-events-auto"
                onClick={() => window.dispatchEvent(new CustomEvent('toggle-audio'))}
              >
                <img 
                  src="https://lh3.googleusercontent.com/d/1fwexopulqCIrEUcQVy1yesuCjSUYgWdy" 
                  alt="Play Song"
                  className={`w-10 md:w-14 h-10 md:h-14 object-contain transition-all duration-500 ${musicPlaying ? 'drop-shadow-[0_0_25px_rgba(212,175,55,0.8)] scale-110' : 'drop-shadow-[0_0_15px_rgba(212,175,55,0.6)]'}`}
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-6 md:gap-10 mt-6 md:mt-10">
              <h1 className={`font-royal-decorative text-5xl md:text-8xl text-[#c5a059] khamma-ghani-glow tracking-widest whitespace-nowrap transition-all duration-1000 ${musicPlaying ? 'brightness-125' : 'brightness-100'}`}>
                Khamma Ghani
              </h1>
              <img 
                src="https://lh3.googleusercontent.com/d/1I5OsI8cKsEZZhUrQ2_myypDzSfl4Sq9e" 
                alt="Namaste Greeting"
                className={`w-16 md:w-24 h-auto drop-shadow-[0_0_30px_rgba(197,160,89,0.5)] transition-all duration-1000 ${musicPlaying ? 'brightness-150 scale-110' : 'brightness-125'}`}
                referrerPolicy="no-referrer"
              />
            </div>

            <motion.div 
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ delay: 1.2, duration: 1.5 }}
              className={`h-[1px] w-48 md:w-[600px] bg-gradient-to-r from-transparent via-[#c5a059] to-transparent mt-8 transition-opacity duration-1000 ${musicPlaying ? 'opacity-80' : 'opacity-40'}`}
            />

            <p className={`font-royal italic text-lg md:text-2xl tracking-[0.15em] text-[#f5f5ed] museum-text-shadow uppercase mt-6 transition-all duration-1000 ${musicPlaying ? 'opacity-100' : 'opacity-90'}`}>
              "Where Every Grain of Sand Holds a Story"
            </p>
          </div>
        </motion.div>
      </section>

      {/* Regions Grid Section with Heritage Background */}
      <section className="relative py-32 px-6 overflow-hidden">
        {/* Background Overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://lh3.googleusercontent.com/d/1196-ZfHOd9r3jZpD5yTKtwIGQjLkv5si" 
            alt="Heritage Background"
            className={`w-full h-full object-cover transition-all duration-1000 opacity-80 ${musicPlaying ? 'brightness-[0.9] contrast-[1.1]' : 'brightness-[0.75] contrast-[1.05]'}`}
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#050505] via-transparent to-[#050505]" />
          <div className={`absolute inset-0 bg-[#050505]/20 transition-opacity duration-1000 ${musicPlaying ? 'opacity-0' : 'opacity-100'}`} />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="mb-24 text-center">
            <h2 className="font-serif text-4xl md:text-5xl mb-4 museum-text-shadow">Majestic Regions</h2>
            <div className="w-24 h-[1px] bg-[#c5a059] mx-auto opacity-50" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-y-24 gap-x-12 lg:gap-x-16">
            {regions.map((region, index) => (
              <motion.div
                key={region.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.6 }}
                className="monument-structure rounded-t-3xl"
              >
                <Link 
                  to={`/region/${region.id}`}
                  className="group block relative aspect-[4/5] overflow-hidden rounded-lg bg-[#050505] transition-all duration-500 shadow-[0_20px_50px_rgba(0,0,0,0.8)]"
                  style={{ 
                    // @ts-ignore - custom property for hover
                    '--hover-color': region.theme.primary 
                  } as any}
                  onMouseEnter={(e) => {
                    e.currentTarget.parentElement!.style.background = `linear-gradient(135deg, ${region.theme.primary}, transparent, ${region.theme.primary})`;
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.parentElement!.style.background = 'linear-gradient(135deg, rgba(197, 160, 89, 0.4), transparent, rgba(197, 160, 89, 0.4))';
                  }}
                >
                  {/* Decorative Monument Corner Accents */}
                  <div className="absolute top-0 left-0 w-12 h-12 border-t-2 border-l-2 opacity-30 group-hover:opacity-100 transition-opacity duration-500 z-30" style={{ borderColor: region.theme.primary }} />
                  <div className="absolute top-0 right-0 w-12 h-12 border-t-2 border-r-2 opacity-30 group-hover:opacity-100 transition-opacity duration-500 z-30" style={{ borderColor: region.theme.primary }} />
                  <div className="absolute bottom-0 left-0 w-12 h-12 border-b-2 border-l-2 opacity-30 group-hover:opacity-100 transition-opacity duration-500 z-30" style={{ borderColor: region.theme.primary }} />
                  <div className="absolute bottom-0 right-0 w-12 h-12 border-b-2 border-r-2 opacity-30 group-hover:opacity-100 transition-opacity duration-500 z-30" style={{ borderColor: region.theme.primary }} />

                  <img 
                    src={region.image} 
                    alt={region.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale-[0.2] group-hover:grayscale-0 brightness-[0.7] group-hover:brightness-100"
                    referrerPolicy="no-referrer"
                  />
                  
                  {/* Pattern Overlay */}
                  <div 
                    className={`absolute inset-0 opacity-[0.05] group-hover:opacity-[0.12] transition-opacity pointer-events-none mix-blend-overlay ${region.patternClass || ''}`} 
                  />

                  <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black via-black/40 to-transparent z-10" />
                  
                  <div className="absolute bottom-0 left-0 p-8 w-full z-20 translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
                    <motion.span 
                      className="text-[11px] uppercase tracking-[0.3em] font-bold block mb-3 museum-text-shadow"
                      style={{ color: region.theme.primary }}
                    >
                      {region.title}
                    </motion.span>
                    <h3 
                      className={`${region.theme.headingFont} text-4xl museum-text-shadow transition-colors duration-300`}
                    >
                      {region.name}
                    </h3>
                    
                    {/* View Details Indicator */}
                    <div className="mt-6 flex items-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                      <div className="h-[1px] w-8 bg-[#c5a059]" />
                      <span className="text-[10px] uppercase tracking-widest text-[#c5a059]">Enter Region</span>
                    </div>
                  </div>

                  {/* Monument Silhouette Overlay (Lightly visible) */}
                  <div className="absolute inset-0 border-[20px] border-black/20 pointer-events-none group-hover:border-black/0 transition-all duration-700" />
                </Link>

                {/* Monument-like shadow structure below the card */}
                <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-4/5 h-12 bg-black/40 blur-2xl rounded-full -z-10" />
              </motion.div>
            ))}
          </div>
        </div>
      </section>
      <footer className="py-20 text-center opacity-30 text-xs tracking-[0.4em] uppercase bg-[#050505]">
        Explore the Heart of India
      </footer>
    </motion.main>
  );
}
