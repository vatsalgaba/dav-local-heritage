import { motion } from 'motion/react';
import { History as HistoryIcon, Shield, Crown, Landmark } from 'lucide-react';
import { Link } from 'react-router-dom';

const TIMELINE = [
  {
    era: "8th - 11th Century",
    title: "The Gurjara-Pratiharas",
    description: "The dawn of the Rajput era. A period of magnificent temple construction and resistance against early invasions.",
    icon: Landmark
  },
  {
    era: "12th Century",
    title: "The Chauhan Majesty",
    description: "Prithviraj Chauhan III's reign marks the height of Rajput valor. Delhi and Ajmer become centers of Hindu power.",
    icon: Shield
  },
  {
    era: "13th - 16th Century",
    title: "The Age of Resistance",
    description: "The rise of the Sisodia dynasty in Mewar. Legendary figures like Maharana Pratap and Rana Sanga defend the hills.",
    icon: Crown
  },
  {
    era: "18th Century",
    title: "Scientific Enlightenment",
    description: "Maharaja Sawai Jai Singh II founds Jaipur, blending astronomical science with architectural excellence.",
    icon: HistoryIcon
  }
];

export function History() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="pt-20 pb-20 px-6 min-h-screen bg-[#050505] relative overflow-hidden"
    >
      {/* Decorative side text */}
      <div className="fixed left-4 top-1/2 -translate-y-1/2 -rotate-90 origin-left text-[8px] uppercase tracking-[1em] text-white/10 select-none whitespace-nowrap">
        Sands of Time • Chronicles of Valor • Legacy of Kings
      </div>

      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-32">
          <motion.span 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="text-[10px] uppercase tracking-[0.6em] text-[#c5a059] font-bold"
          >
            Temporal Archive
          </motion.span>
          <motion.h1 
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="font-royal text-5xl md:text-7xl mt-6 mb-8 text-[#f5f5ed]"
          >
            Ancient Echoes
          </motion.h1>
          <div className="w-40 h-[1px] bg-[#c5a059]/30 mx-auto" />
        </header>

        <div className="relative">
          {/* Vertical central line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-[1px] bg-gradient-to-b from-[#c5a059]/40 via-[#c5a059]/10 to-transparent -translate-x-1/2 hidden md:block" />

          <div className="space-y-24">
            {TIMELINE.map((item, idx) => (
              <TimelineItem key={idx} {...item} index={idx} />
            ))}
          </div>
        </div>

        <div className="mt-48 text-center border-t border-white/5 pt-20">
          <p className="font-traditional italic text-lg text-white/40 mb-12">
            "The story of Rajasthan is not written in ink, but in the sweat of its people and the blood of its warriors."
          </p>
          <Link to="/" className="inline-block px-12 py-4 border border-white/10 text-[10px] uppercase tracking-[0.4em] text-white/60 hover:text-white hover:border-white transition-all rounded-full font-bold">
            Exit to Courtyard
          </Link>
        </div>
      </div>
    </motion.div>
  );
}

function TimelineItem({ era, title, description, icon: Icon, index }: any) {
  const isEven = index % 2 === 0;
  
  return (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`relative grid grid-cols-1 md:grid-cols-2 gap-12 group`}
    >
      <div className={`${isEven ? 'md:text-right order-2 md:order-1' : 'order-2'} space-y-4`}>
        <span className="text-[10px] uppercase tracking-widest text-[#c5a059] font-bold block opacity-40">{era}</span>
        <h3 className="font-royal text-2xl text-white group-hover:text-[#c5a059] transition-colors">{title}</h3>
        <p className="text-sm text-white/50 leading-relaxed font-traditional italic">{description}</p>
      </div>

      <div className={`hidden md:flex ${isEven ? 'justify-start' : 'justify-end'} order-3 items-center`}>
        <div className="p-4 border border-[#c5a059]/20 rounded-full bg-[#080808] text-[#c5a059] group-hover:scale-110 group-hover:bg-[#c5a059] group-hover:text-black transition-all duration-500">
          <Icon className="w-8 h-8" />
        </div>
      </div>

      {/* Point on center line */}
      <div className="absolute left-1/2 top-10 -translate-x-1/2 w-3 h-3 rounded-full bg-[#c5a059] hidden md:block border-4 border-[#050505] shadow-[0_0_15px_rgba(197,160,89,0.5)]" />
    </motion.div>
  );
}
