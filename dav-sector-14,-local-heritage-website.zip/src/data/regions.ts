export interface RegionTheme {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  contrast: string;
  headingFont: string;
  bodyFont: string;
}

export interface Attraction {
  name: string;
  description: string;
  image: string;
}

export interface Region {
  id: string;
  name: string;
  title: string;
  description: string;
  image: string;
  landmark: string;
  landmarkImage?: string;
  history: string;
  culture: string;
  architecture: string;
  cuisine: string;
  folklore: string;
  attractions: Attraction[];
  theme: RegionTheme;
  patternClass?: string;
  coordinates?: { lat: number; lng: number };
}

export const regions: Region[] = [
  {
    id: 'chittorgarh',
    name: 'Chittorgarh',
    title: 'The City of Bravery',
    description: 'Chittorgarh is the epitome of Rajput pride, romance and spirit. It echoes with the tales of valor and sacrifice which are unique in the world. The formidable fort of Chittorgarh, perched on a 180-meter high hill, spans over 700 acres and served as the capital of the Mewar Kingdom for centuries.',
    image: 'https://lh3.googleusercontent.com/d/1w0coxy-DTCV2K2MZzI8koxm17aXTl0WD',
    landmark: 'Chittorgarh Fort',
    landmarkImage: 'https://lh3.googleusercontent.com/d/1ssQx4jhiPRcGqNeWDqfj_v0iBMbTWnXJ', // Grand Architecture
    history: 'The fort has been besieged three times in its history, lead by Alauddin Khalji in 1303, Bahadur Shah of Gujarat in 1535, and Mughal Emperor Akbar in 1567. Each time, the defenders fought to the last man while the women performed Jauhar.',
    culture: 'The local culture is deeply rooted in the legends of Mirabai, the poet-saint, and the heroic resistance of the Sisodia Rajputs. Folk songs still recount the beauty of Rani Padmini and the bravery of Jaimal and Patta.',
    architecture: 'The fort is an architectural marvel with seven massive gates (Pols), intricate temples like the Samadhishvara Temple, and towering structures like the Vijay Stambha (Victory Tower) and Kirti Stambha (Tower of Fame).',
    cuisine: 'Experience the robust flavors of Mewar, where the cuisine was designed for the rigors of desert life and battle. Signature dishes include Laal Maas (spicy mutton), various forms of Ker Sangri, and thick, wholesome rotis cooked over open fires.',
    folklore: 'The most enduring legend is that of Rani Padmini, whose beauty was so great that Alauddin Khalji was permitted only to see her reflection in a mirror, a sight that eventually led to a historic siege and a mass sacrifice.',
    attractions: [
      {
        name: 'Vijay Stambha',
        description: 'The Tower of Victory, built by Maharana Kumbha to commemorate his victory over the armies of Malwa and Gujarat.',
        image: 'https://lh3.googleusercontent.com/d/1xUqy41T5DarDp7S6P68f9uC36y7T7dAi'
      },
      {
        name: 'Kirti Stambha',
        description: 'The Tower of Fame, dedicated to the first Jain Tirthankara, Adinath, and adorned with intricate Jain sculptures.',
        image: 'https://lh3.googleusercontent.com/d/1yo0jXMz4DybOYD6bBFUFJnPVxjfHtLHu'
      },
      {
        name: 'Padmini\'s Palace',
        description: 'A white building surrounded by a water moat, legendary as the spot where Alauddin Khalji glimpsed Rani Padmini.',
        image: 'https://lh3.googleusercontent.com/d/1NmmCdirMhFNbja88vnio9Nx-yy9Jt7z0'
      }
    ],
    coordinates: { lat: 24.8829, lng: 74.6231 },
    theme: {
      primary: '#8B6F47',
      secondary: '#7A1F1F',
      accent: '#C49A44',
      background: '#F3E9D2',
      contrast: '#3E2C24',
      headingFont: 'font-medieval',
      bodyFont: 'font-serif'
    },
    patternClass: 'pattern-warrior'
  },
  {
    id: 'jodhpur',
    name: 'Jodhpur',
    title: 'Blue City Desert Majesty',
    description: 'Jodhpur, the "Blue City," is a mesmerizing sight from the ramparts of Mehrangarh Fort. The old city is a tangled web of medieval streets, many of which are lined with houses painted in a vibrant indigo blue, originally to indicate the residency of Brahmins and to keep the homes cool.',
    image: 'https://lh3.googleusercontent.com/d/1KRzbvzhTf6I9Z0TvVC0J7noE_0Cjbl91',
    landmark: 'Mehrangarh Fort',
    landmarkImage: 'https://images.unsplash.com/photo-1589182337358-2cb63099300a?auto=format&fit=crop&q=80&w=800',
    history: 'The city was founded in 1459 by Rao Jodha, a chief of the Rathore clan. Jodhpur was the capital of the Marwar state, and the Rathores claimed descent from the Sun God (Suryavansha). The massive Mehrangarh Fort was never taken by force.',
    culture: 'Jodhpur is famous for its vibrant textiles, including the Bandhani (tie-dye) technique, and its energetic folk music and dance. The city also hosts the Jodhpur RIFF, an international festival celebrating the soul of Rajasthan\'s musical heritage.',
    architecture: 'The architecture is dominated by the Mehrangarh Fort, with its thick walls and intricate stonework. Inside, the Moti Mahal, Phool Mahal, and Sheesh Mahal showcase the exquisite craftsmanship of the Rajput era, with delicate jali work and gilded ceilings.',
    cuisine: 'Jodhpur is a paradise for street food lovers. The legendary Mirchi Bada, Mawa Kachori, and Saffron Lassi are must-tries. The royal kitchens also gave birth to decadent dishes like Dal Bhaati Churma and various ker-sangri preparations.',
    folklore: 'The construction of Mehrangarh Fort is shrouded in legends, including the story of a hermit named Cheeria Nathji, who was displaced from the hill and cursed the fort with a drought. To neutralize the curse, a man named Rajiya Bhambi was buried alive in the foundations.',
    attractions: [
      {
        name: 'Umaid Bhawan Palace',
        description: 'One of the world\'s largest private residences, part of which is managed by Taj Hotels.',
        image: 'https://lh3.googleusercontent.com/d/1gMgFnVhAlXyqpsFCJo0LTg-D6OjpB942'
      },
      {
        name: 'Jaswant Thada',
        description: 'A milky-white marble cenotaph built in 1899 in memory of Maharaja Jaswant Singh II.',
        image: 'https://lh3.googleusercontent.com/d/1-NSnsZ2pGJBE9KtF8EDvhnbrK_p6SSG-'
      },
      {
        name: 'Mandore Gardens',
        description: 'The ancient capital of Marwar, featuring high-rock terraces and beautiful cenotaphs.',
        image: 'https://lh3.googleusercontent.com/d/1KyUdV_uj3wom7Ce7UvFl1B0HMTKBO9Bo'
      }
    ],
    coordinates: { lat: 26.2389, lng: 73.0243 },
    theme: {
      primary: '#3F72AF',
      secondary: '#D9C3A5',
      accent: '#C58B3A',
      background: '#F8F5F0',
      contrast: '#1D3557',
      headingFont: 'font-geometric font-bold',
      bodyFont: 'font-clean'
    },
    patternClass: 'pattern-desert'
  },
  {
    id: 'jaipur',
    name: 'Jaipur',
    title: 'The Pink City Royalty',
    description: 'Jaipur, the capital of Rajasthan, is a symphony in pink. Known for its wide streets and planned layout, the city is a blend of traditional Rajput architecture and the scientific vision of its founder. It remains one of the most vibrant cultural centers in Asia.',
    image: 'https://lh3.googleusercontent.com/d/1DtIrexOWX7LncIihLQrSfPk-gdXDklEG',
    landmark: 'Hawa Mahal',
    landmarkImage: 'https://lh3.googleusercontent.com/d/1_y_o_u_x_g_y_z_w_v_r_e_t_h_i_n_g', // Amber Fort
    history: 'Founded in 1727 by Maharaja Sawai Jai Singh II, the city was built according to the principles of Vastu Shastra and Shilpa Shastra. It became the capital of the Kachwaha Rajputs and shifted from the old capital of Amber.',
    culture: 'The city is a hub for crafts, including blue pottery, block printing, and gemstone cutting. Festivals like the Jaipur Literature Festival and Teej bring the city to life with intellectual discourse and traditional celebrations.',
    architecture: 'From the iconic Hawa Mahal (Palace of Winds) with its 953 small windows to the sprawling City Palace complex and the astronomical wonders of the Jantar Mantar, the architecture reflects both aesthetic beauty and mathematical precision.',
    cuisine: 'Jaipur offers a royal culinary experience. Famous for its Dal Baati Churma, Ker Sangri, and the sweet Ghevar, the city also prides itself on its Pyaaz Kachori and the spicy Lal Maas from the royal kitchens.',
    folklore: 'Legends abound in Jaipur, including tales of the Amber Fort\'s hidden treasures and the astronomical predictions made by the astronomers of the Jantar Mantar, which are said to be accurate to this day.',
    attractions: [
      {
        name: 'Amber Fort',
        description: 'A UNESCO World Heritage site known for its artistic Hindu-style elements and breathtaking views.',
        image: 'https://lh3.googleusercontent.com/d/1HJVLD-hyd3avmLLFD07nKS8_HV4vE9hU'
      },
      {
        name: 'City Palace',
        description: 'A palace complex that serves as a residence for the royal family, featuring impressive museums and courtyards.',
        image: 'https://lh3.googleusercontent.com/d/1Ibk7erJWzM5eDSaerPc5mmuAKgv1KrPI'
      },
      {
        name: 'Jantar Mantar',
        description: 'An astronomical observatory built in 1734 with the world\'s largest stone sundial.',
        image: 'https://lh3.googleusercontent.com/d/1LnvB5G2ybC4McarPKSacCe3RhF4Y-eqh'
      }
    ],
    coordinates: { lat: 26.9124, lng: 75.7873 },
    theme: {
      primary: '#D97B66',
      secondary: '#F2B8A0',
      accent: '#D89B2B',
      background: '#F6E7D8',
      contrast: '#5A3E36',
      headingFont: 'font-royal-decorative',
      bodyFont: 'font-sans'
    },
    patternClass: 'pattern-jharokha'
  },
  {
    id: 'bikaner',
    name: 'Bikaner',
    title: 'The Desert Jewel',
    description: 'Bikaner, located in the heart of the Thar Desert, is a city built on the grit and glamour of the ancient spice and silk routes. Its red sandstone architecture glows at sunset, and its massive forts remain remarkably well-preserved through the centuries.',
    image: 'https://lh3.googleusercontent.com/d/1IdUKe2ugS5L4YR8fhIcWGubHPAw0iSAk',
    landmark: 'Junagarh Fort',
    landmarkImage: 'https://lh3.googleusercontent.com/d/1_b_i_k_a_n_e_r_k_a_r_n_i_m_a_t_a', // Karni Mata
    history: 'Founded in 1488 by Rao Bika, a prince of the Rathore clan who chose this arid land to build his own kingdom. Unlike many other forts in Rajasthan, Junagarh is one of the few major forts not built on a hilltop, yet it was never conquered.',
    culture: 'The city is world-renowned for its artistic heritage, particularly the Usta Art (miniature painting on camel hide) and the vibrant camel hair cutting art seen during the Bikaner Camel Festival.',
    architecture: 'Junagarh Fort is a masterpiece of red sandstone and marble, featuring opulent halls like the Anup Mahal, decorated with gold leaf, and the Badal Mahal, with blue and white clouds painted on its walls to evoke the spirit of rain.',
    cuisine: 'Bikaner is the birthplace of the world-famous Bikaneri Bhujia. The local palate is also famous for its savory Rasgullas and the traditional desert dish Ker-Sangri, made from the berries and beans of the stunted desert trees.',
    folklore: 'The city is intrinsically linked to the Karni Mata Temple in nearby Deshnok, where 20,000 sacred white rats (kabbas) are worshipped. Legend says they are the reincarnated souls of the temple\'s devotees.',
    attractions: [
      {
        name: 'Karni Mata Temple',
        description: 'The world-famous temple of rats, where over 25,000 black rats live and are worshipped.',
        image: 'https://lh3.googleusercontent.com/d/16mbx2GMsRhhA9-HCgYkqBF-p1JWuyJp0'
      },
      {
        name: 'Lallgarh Palace',
        description: 'A magnificent palace built in red sandstone, combining Rajput, Mughal, and European styles.',
        image: 'https://lh3.googleusercontent.com/d/18FjYLx213fQ9ANfvoQ8wfVoICRVEjRPl'
      },
      {
        name: 'Gajner Palace',
        description: 'A lakeside palace often called "The Jewel in the Thar Desert," formerly a hunting lodge.',
        image: 'https://lh3.googleusercontent.com/d/1pFqWTFHIvcN7KcAI-qFvb-99lNNF9nVe'
      }
    ],
    coordinates: { lat: 28.0223, lng: 73.3119 },
    theme: {
      primary: '#A64B2A',
      secondary: '#D8B384',
      accent: '#D9A404',
      background: '#F7E8D0',
      contrast: '#5B3924',
      headingFont: 'font-traditional italic',
      bodyFont: 'font-traditional'
    }
  },
  {
    id: 'neemrana',
    name: 'Neemrana',
    title: 'The Gateway of Heritage',
    description: 'Neemrana is where the sky meets the Aravallis. Perched high above the historic Alwar highway, its tiered architecture flows down the mountainside, offering a majestic panoramic view of the surrounding countryside.',
    image: 'https://lh3.googleusercontent.com/d/1olzXgSwr1Ia5lacCepstj2cTuXv3uOn9',
    landmark: 'Neemrana Fort Palace',
    history: 'Neemrana was the third capital of the descendants of Maharaja Prithviraj Chauhan III, who fled to the Aravalli hills after being defeated by Mohammad Ghori in the 12th century. The fort palace itself dates back to 1464.',
    culture: 'Today, Neemrana is a symbol of successful heritage restoration. It blends historical regality with modern lifestyle, acting as a bridge between Alwar\'s martial history and contemporary Rajasthani hospitality.',
    architecture: 'The site features 14-tiered fort architecture, with palaces built over ten levels. The maze-like structure includes beautiful hanging gardens, wide courtyards, and narrow winding corridors that were once used for defensive tactical maneuvers.',
    cuisine: 'In Neemrana, one can savor the fusion of royal Alwar recipes with modern influences. Signature dishes include the spicy Gatte-ki-Sabzi and the sweet, milky Kalakand (milk cake), for which the Alwar region is famous.',
    folklore: 'Local legends speak of the Chauhan dynasty\'s undying spirit and the hidden passageways that once connected the fort to distant mountain outposts, used for communication during times of war.',
    attractions: [
      {
        name: 'The Baori',
        description: 'A magnificent nine-story step-well that served as a crucial water resource and cooling retreat.',
        image: 'https://lh3.googleusercontent.com/d/1-r62mkG3Xua5IhC5Mjlyuh9cdO_ReTQY'
      },
      {
        name: 'Siliserh Lake',
        description: 'A serene lake near Alwar with a beautiful royal palace turned hotel overlooking the water.',
        image: 'https://lh3.googleusercontent.com/d/1FD8ONz85DbDXlkL2NgUHYTdj4ecnmaMV'
      },
      {
        name: 'Bala Quila',
        description: 'The ancient Alwar Fort perched on a cliff, offering panoramic views of the Aravalli hills.',
        image: 'https://lh3.googleusercontent.com/d/1gZcZV17XUz0Vbr87Jgd3fpvVYPc8o59A'
      }
    ],
    coordinates: { lat: 28.0000, lng: 76.3881 },
    theme: {
      primary: '#B68D40',
      secondary: '#7A8450',
      accent: '#6D213C',
      background: '#F5F0E6',
      contrast: '#32221A',
      headingFont: 'font-luxury',
      bodyFont: 'font-clean font-light'
    }
  },
  {
    id: 'pushkar',
    name: 'Pushkar',
    title: 'The Holy City',
    description: 'Pushkar is a rare town where spirituality and desert culture converge around a sacred lake. It is one of the few places in the world dedicated to Lord Brahma, the creator of the universe, and possesses a divine, timeless atmosphere.',
    image: 'https://lh3.googleusercontent.com/d/1R-WyQ9j4OGzMnw3XYj-tuSp3k5OfBWaw',
    landmark: 'Brahma Temple',
    history: 'Pushkar is considered one of the oldest existing cities in India. It is mentioned in the Ramayana, the Mahabharata, and the Puranas as a significant tirtha (pilgrimage site) for over two millennia.',
    culture: 'The town is a vibrant kaleidoscope of colors, particularly during the Pushkar Camel Fair, where thousands of camels, horses, and cattle are traded amidst a carnival of folk music, dance, and religious ceremonies.',
    architecture: 'The architecture of Pushkar is defined by its 52 bathing ghats that step down into the Pushkar Lake and over 400 temples. The Brahma Temple, with its red spire and marble floors, is the most significant architectural landmark.',
    cuisine: 'As a holy city, Pushkar is strictly vegetarian. It is famous for its Malpuas (sweet pancakes), Lassi, and Dal Kachoris. The local food is made with simple ingredients but carries deep, traditional flavors.',
    folklore: 'According to Hindu mythology, Lord Brahma was looking for a place to perform a grand yajna (sacrifice) and dropped a lotus flower; where the petals fell, Pushkar Lake emerged, hence the name Pushkar (Pushpa/flower, Kar/hand).',
    attractions: [
      {
        name: 'Pushkar Lake & Ghats',
        description: 'The heart of Pushkar, with 52 ghats used by pilgrims for ceremonial bathing.',
        image: 'https://lh3.googleusercontent.com/d/1f_Yl0Jh3plbTf1bPLWuEasYB7JAgvEQj'
      },
      {
        name: 'Savitri Temple',
        description: 'A temple dedicated to Savitri, the first wife of Lord Brahma, located atop Ratnagiri Hill.',
        image: 'https://lh3.googleusercontent.com/d/17lCNN6K78_4nYhmaK5uVegz0DU95wiS6'
      },
      {
        name: 'Varaha Temple',
        description: 'One of the oldest temples in Pushkar, dedicated to the Varaha avatar of Lord Vishnu.',
        image: 'https://lh3.googleusercontent.com/d/1A_Ar7oKvDLIS_vAUO2pMU6_4HQYLVQox'
      }
    ],
    coordinates: { lat: 26.4897, lng: 74.5511 },
    theme: {
      primary: '#E67E22',
      secondary: '#5DADE2',
      accent: '#922B21',
      background: '#FAF3E0',
      contrast: '#4A2C2A',
      headingFont: 'font-artistic',
      bodyFont: 'font-sans'
    },
    patternClass: 'pattern-mandala'
  }
];
